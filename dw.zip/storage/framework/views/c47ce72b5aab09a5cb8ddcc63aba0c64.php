<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Stock Product</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet"/>
    <link href="https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap5.css" rel="stylesheet"/>
    <link href="https://cdn.datatables.net/buttons/3.0.2/css/buttons.bootstrap5.css" rel="stylesheet"/>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"/>
</head>
<?php /**PATH D:\Job seeker\Nutech\nutech\resources\views\components\header.blade.php ENDPATH**/ ?>