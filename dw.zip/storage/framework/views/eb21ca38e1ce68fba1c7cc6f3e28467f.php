<!doctype html>
<html lang="en">
  <?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <body>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('components.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html>
<?php /**PATH D:\Job seeker\Nutech\nutech\resources\views/components/layout.blade.php ENDPATH**/ ?>