<!doctype html>
<html lang="en">
  @include('components.header')
  <body>
    @yield('content')
    @include('components.script')
  </body>
</html>
